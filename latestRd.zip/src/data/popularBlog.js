const popularBlog = [
  {
    title: "Why Choose Research Developers?",
    pathName: "/blogdetails/",
  },
  {
    title: "How We Help with Topic Selection",
    pathName: "/blogdetails/blog2",
  },
  {
    title: "Why Thesis Editing Service?",
    pathName: "/blogdetails/blog3",
  },
  {
    title: "Topics in Mechanical Engineering",
    pathName: "/blogdetails/blog4",
  },
  {
    title: "Projects in MATLAB",
    pathName: "/blogdetails/blog5",
  },
  {
    title: "Topics in Civil Engineering",
    pathName: "/blogdetails/blog6",
  },
  {
    title: "Topics in Deep Learning",
    pathName: "/blogdetails/blog7",
  },
  {
    title: "Topics in Signal Processing",
    pathName: "/blogdetails/blog8",
  },
  {
    title: "Topics in Covid related research",
    pathName: "/blogdetails/blog9",
  },
  {
    title: "Topics in Machine Learning",
    pathName: "/blogdetails/blog10",
  },
  {
    title: "Topics in IoT",
    pathName: "/blogdetails/blog11",
  },
  {
    title: "Topics in Consumer Behaviour",
    pathName: "/blogdetails/blog12",
  },
  {
    title: "Topics in English Literature",
    pathName: "/blogdetails/blog13",
  },
  {
    title: "NLP PhD Thesis Topics",
    pathName: "/blogdetails/blog14",
  },
  {
    title: "Projects in Hadoop",
    pathName: "/blogdetails/blog15",
  },
  {
    title: "Wifi Network Simulation",
    pathName: "/blogdetails/blog16",
  },
  {
    title:
      "WHY IS OUR RESEARCH-BASED PHD THESIS WRITING SERVICE CONSIDERED THE BEST IN INDIA?",
    pathName: "/blogdetails/blog17",
  },
  {
    title: "HOW WE CREATE OUTSTANDING PHD RESEARCH PROPOSALS?",
    pathName: "/blogdetails/blog18",
  },
  {
    title:
      "HOW TO ENHANCE YOUR RESEARCH WITH OUR PHD THESIS WRITING ASSISTANCE?",
    pathName: "/blogdetails/blog19",
  },
  {
    title:
      "THE SYNERGY OF MIND AND MACHINE. GET YOUR THESIS ENHANCED BY EXPERTS.",
    pathName: "/blogdetails/blog20",
  },
  {
    title: "HOW TO MEET YOUR PHD GOALS WITH CONFIDENCE?",
    pathName: "/blogdetails/blog21",
  },
  {
    title:
      "MITIGATE HIGH RESEARCH PAPER REJECTIONS WITH OUR STRATEGIC SOLUTIONS",
    pathName: "/blogdetails/blog22",
  },
  {
    title: "PHD RESEARCH PAPER WRITING SERVICES & PUBLICATION SUPPORT",
    pathName: "/blogdetails/blog23",
  },
  {
    title: "BENEFITS OF CHOOSING OUR SYSTEMATIC LITERATURE REVIEW SERVICE",
    pathName: "/blogdetails/blog24",
  },
  {
    title: "WHY CHOOSING OUR SERVICE IS THE BEST IDEA FOR YOUR THESIS?",
    pathName: "/blogdetails/blog25",
  },
];
export default popularBlog;
