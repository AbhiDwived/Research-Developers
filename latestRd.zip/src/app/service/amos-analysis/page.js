import React from 'react' 
import ServiceDetail from "../../../pages/services/page"
const Page = () => {
  return (
    <div>
      <ServiceDetail/>
    </div>
  )
}

export default Page
