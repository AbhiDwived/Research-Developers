import Navbar from '@/pages/header/Navbar'
import React from 'react'
import Career from "../../pages/career/page"
const Careers = () => {
  return (
    <div>
      <div className='md:mt-5 mt-5 '>
        <Navbar/>
      </div>
      <Career/>
    </div>
  )
}

export default Careers
